/*
 * Copyright 2021, CNRS
 */

// Including this header should not raise a build error

#include "eigenpy/registration.hpp"

BOOST_PYTHON_MODULE(include) {}
