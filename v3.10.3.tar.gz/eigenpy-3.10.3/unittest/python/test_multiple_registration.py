import multiple_registration  # noqa
