import eigenpy

assert eigenpy.checkVersionAtLeast(0, 0, 0)
assert eigenpy.__version__ != ""
assert eigenpy.__raw_version__ != ""
